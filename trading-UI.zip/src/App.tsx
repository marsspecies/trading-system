import React, { useEffect } from 'react'

import Chart from './components/charts/Chart'
import logo from './logo.svg'
import './App.css'

function App() {
  return (
    <div className="App">
      <Chart></Chart>
    </div>
  )
}

export default App
